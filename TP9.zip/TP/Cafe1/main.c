#include <stdio.h>
#include "automate.h"

int main() {
automate A ;
	init_mon_automate(&A) ;
	simule_automate(&A) ;
	return 0 ;
}	
